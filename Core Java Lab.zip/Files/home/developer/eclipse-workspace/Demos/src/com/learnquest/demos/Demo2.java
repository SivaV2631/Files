package com.learnquest.demos;

public class Demo2 extends Demo1 {

	public Demo2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Demo2(String name, int speed) {
		super(name, speed);
		
	}

	public Demo2(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	
	
}
