package com.learnquest.demos;

public class Demo1 {
			private int speed;
			private String name;
			
			public Demo1() {}
			public Demo1(String name) {
				this.name =name;
			}			
			public Demo1(String name, int speed) {
				this.name=name;
				this.speed=speed;
				
			}
	public String getName() {
				return name;
			}

			public void setName(String name) {
				this.name = name;
			}

	public int getSpeed() {
				return speed;
			}

			public void setSpeed(int speed) {
				this.speed = speed;
			}

			
			@Override
			public boolean equals(Object obj) {
				// TODO Auto-generated method stub
				if(!(obj instanceof Demo1))
					return false;
				Demo1 other= (Demo1) obj;
				return name.equals(other.getName());
			}
			@Override
			public int hashCode() {
				// TODO Auto-generated method stub
				return name.hashCode();
			}
			@Override
			public String toString() {
				// TODO Auto-generated method stub
				return  String.format("%s is running at %d speed.", getName(), getSpeed()); 

			}
	
		
		
		
	}


