package DemoApps;

import com.learnquest.demos.Demo1;
import com.learnquest.demos.Demo2;

public class DemoApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1 d= new Demo1();
		d.setName("Demo1");
		d.setSpeed(100);
		
		Demo1 d1= new Demo2("Demo2", 200);
		
		for(Demo1 demo : new Demo1[] { d, d1}) {
			System.out.println(demo);	
		}
	}

}
