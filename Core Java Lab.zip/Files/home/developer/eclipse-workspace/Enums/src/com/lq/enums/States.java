package com.lq.enums;

public enum States {
	
	AP("Andhra Pradesh", "Vijayawada"),
	KA("Karnataka", "Bengaluru"),
	TN("TamilNadu", "Chennai");

	private String state;
	private String capital;
	
	private States(String state, String capital) {
		this.state = state;
		this.capital = capital;
		
	}

	public String getState() {
		return state;
	}

	public String getCapital() {
		return capital;
	}
	

	
	
	
}
