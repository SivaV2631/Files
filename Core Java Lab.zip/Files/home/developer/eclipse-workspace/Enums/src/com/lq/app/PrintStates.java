package com.lq.app;

import com.lq.enums.States;

public class PrintStates {

	public static void main(String[] args) {
		
		for(States state : States.values()) {
			System.out.println(state + ": " + state.getState() + ", Capital: " + state.getCapital());
		}

	}

}
