package com.lq.app;

import com.lq.enums.Months;

public class EnumDemo {

	public static void main(String[] args) {
		
		for(Months month : Months.values() ){
			System.out.printf("%d days has %s\n",  month.getDaysInMonth(), month);
		}

	}

}
