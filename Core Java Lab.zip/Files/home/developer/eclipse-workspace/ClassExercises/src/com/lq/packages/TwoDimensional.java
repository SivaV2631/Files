package com.lq.packages;

public interface TwoDimensional {
	
	public double getArea();
	
	public double getPerimeter();
}
