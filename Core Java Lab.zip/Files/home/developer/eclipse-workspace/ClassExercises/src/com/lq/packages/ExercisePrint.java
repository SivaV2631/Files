package com.lq.packages;

public class ExercisePrint {

	public static void main(String[] args) {
		
		Shape[] shapes = new Shape[5];
		
		shapes[0]= new Rectangle(10, 20, "Rectangle", "green");
		shapes[1]= new Square(5, 10, "Square", "red");
		shapes[2]= new Cube(10, "Cube", "violet");
		shapes[3]= new Box(10,"Box", "blue");
		shapes[4]= new Circle(5.00, "Circle", "yellow");
		
		for(Shape shape: shapes) {
			System.out.println(shape);
		}
		
		

	}


}
