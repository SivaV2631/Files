package com.lq.packages;

public class Rectangle extends Shape implements TwoDimensional{
	
	public Rectangle(double length, double width) {
		this(length, width, "White", "Unknown");
	}
	
	public Rectangle(double length, double width, String name, String color) {
		super();
		setName(name);
		setColor(color);
		setLength(length);
		setWidth(width);
	}
	
	private double length;
	private double width;
	
	public double getLength() {
		return length;
	}
	
	public void setLength(double length) {
		this.length = length;
	}
	
	public double getWidth() {
		return width;
	}
	
	public void setWidth(double width) {
		this.width = width;
	}

	@Override
	public double getArea() {
		return getLength() * getWidth();
	}

	@Override
	public double getPerimeter() {
		return 2 * ( getLength() + getWidth() );
	}
	
	@Override 
	public String toString() {
		
		StringBuilder builder = new StringBuilder();
		
		 builder.append("Rectangle [ Length = ");
		 builder.append(length);
		 builder.append(", Width = ");
		 builder.append(width);
		 builder.append(", Color = ");
		 builder.append(getColor());
		 builder.append(", Name = ");
		 builder.append(getName());
		 builder.append(", Area = ");
		 builder.append(getArea());
		 builder.append(", Perimeter = ");
		 builder.append(getPerimeter() + " ]");
		 
		 return builder.toString();
	}
	
	
	
}
