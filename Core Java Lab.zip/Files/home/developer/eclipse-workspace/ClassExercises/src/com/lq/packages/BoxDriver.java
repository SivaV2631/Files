/**
 * 
 */
package com.lq.packages;


/**
 * @author developer
 *
 */
public class BoxDriver {
	
	/**
	 * 
	 * @param height 
	 * @param width
	 * @param length
	 */
	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box box1= new Box(7,6,5);
		Box box2=  new Box(10);
		
		System.out.println("Box 1 length is " + box1.getLength());
		System.out.println("Box 1 length is " + box1.getWidth());
		System.out.println("Box 1 length is " + box1.getHeight());
		System.out.println("Box 2 length is " + box2.getLength());
		System.out.println("Box 2 length is " + box2.getWidth());
		System.out.println("Box 2 length is " + box2.getHeight());
		
		box1.setLength(3);
		box1.setWidth(4);
		box1.setHeight(5);
		
		System.out.println("Box 1 length = " + box1.getLength() + " ,width = " + box1.getWidth() + " ,height = " + box1.getHeight());
		System.out.println("The Volume of Box 1 is "+ box1.getVolume());
		System.out.println("The Surface Area of Box 1 is "+ box1.getSurfaceArea());
		
		box1.printBox();
		
		box1.setLength(-5);
		box1.printBox();
		
		
		box1.setHeight(-10);
		box1.setWidth(0);
		box1.printBox();
		
		//Challenge Exercise
		System.out.println("Challenge");
		Box box3= new Box(-5,-4,7);
		box3.printBox();
		
		
		
		

	}

}
