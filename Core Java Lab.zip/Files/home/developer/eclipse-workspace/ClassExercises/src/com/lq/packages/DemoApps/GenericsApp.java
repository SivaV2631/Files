package com.lq.packages.DemoApps;

import com.lq.packages.Stack;
import com.lq.packages.StackArray;
import com.lq.packages.transport.Car;
import com.lq.packages.transport.SUV;
import com.lq.packages.transport.SpeedException;
import com.lq.packages.transport.SportsCar;
import com.lq.packages.transport.StationWagon;

public class GenericsApp {
	
	public static Stack<String>  makeStackString(Stack<String> strings){
		strings.push("World");
		strings.push("Hello");
		
		return strings;
	}
	
	public static Stack<Integer> makeStackInteger(Stack<Integer> ints)
	{
		ints.push(5);
		ints.push(4);
		ints.push(2);
		ints.push(1);
		ints.push(1);
		
		return ints;
	}
	
	public static Stack<SportsCar> makeStackSportsCar(Stack<SportsCar> cars){
		cars.push(new SportsCar("MACH1", 250, 21, true));
		cars.push(new SportsCar("MACH2", 250, 21, true));
		cars.push(new SportsCar("MACH3", 250, 21, true));
		cars.push(new SportsCar("MACH4", 250, 21, true));
		cars.push(new SportsCar("MACH5", 250, 21, true));
		
		return cars;
	}
	
	public static Stack<Car> makeStackCar(Stack<Car> cars) throws SpeedException{
		cars.push(new SportsCar("MACH 5", 250,21, true));
		cars.push(new SUV("Jurrasic Explorer"));
		
		return cars;
		
	}
	
	public static Stack<? extends Car> makeStackExtendsCar(Stack<? extends Car> cars){
		//<? extends Car> cannot assign
		//if this were allowed,  we could pass a stack<SUV> and add a SportsCar to it!
		//cars.push(new SportsCar("MACH 5", 250,21, true));
		//cars.push(new SUV("Jurrasic Explorer"));
		
		return cars;
		
	}
	
	public static Stack<? super Car> makeStackSuperCar(Stack<? super Car> cars) throws SpeedException {
		cars.push(new SportsCar("MACH 5", 250,21, true));
		cars.push(new SUV("Jurrasic Explorer"));
		
		return cars;
		
	}
	public static void printStackRaw(Stack stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void raceStackRaw(Stack stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			((SportsCar)e).race();
		}
	}
	
	public static void printStackObject(Stack<Object> stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void printStackString(Stack<String> stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void printStackInteger(Stack<Integer> stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void printStackSportsCar(Stack<SportsCar> stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void printStackCar(Stack<Car> stack) {
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void printStack(Stack<?> stack) {		//WildCard
		//Explicitly allow stack of any type, but what else could we 
		//safely treat it as, other than object?
		for(Object e =stack.pop() ; e!= null ; e= stack.pop()) {
			System.out.println(e);
		}
	}
	
	public static void setSpeedStackCar(Stack<Car> stack) {
		for(Car e =stack.pop() ; e!= null ; e= stack.pop()) {
			try {
				e.setSpeed(25);
			} catch (SpeedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static void setSpeedStackExtendsCar(Stack<? extends Car> stack) {
		for(Car e =stack.pop() ; e!= null ; e= stack.pop()) {
			try {
				e.setSpeed(25);
			} catch (SpeedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	public static void setSpeedStackSuperCar(Stack<? super Car> stack) {
		//<? super X>  cannot read
		//we only know that we have been giving Car or a Super class
		//we could pas a Stack<Object> and it would be OK, we do
		//not know anything about the instances on hand
		//for(Car e =stack.pop() ; e!= null ; e= stack.pop()) {
		//	e.setSpeed(25);
		//}
	}
	
	public static <T> void loadFromArray(Object[] arr, Stack<T> stack){
		for(Object o: arr) {
		//	if(o.instanceof(T)) {	//ERROR
				
		//	}
		}
	}
	
	public static <T> Stack<T> loadFromArray(Object[] arr, Class<T> type){
		Stack<T> stack = new StackArray<>(arr.length);
		for(Object o: arr) {
			if(type.isInstance(o)) {
				stack.push((T) o);
			}
		}
		return stack;
		
	}
	public static void main(String[] args) throws SpeedException {
		//create stacks of diff types
		Stack<String> strings = new StackArray<>();
		Stack<Integer> ints = new StackArray<>();
		Stack<SportsCar> cars = new StackArray<>();
		
		//print them out raw, it works...
		printStackRaw(makeStackString(strings));
		printStackRaw(makeStackInteger(ints));
		printStackRaw(makeStackSportsCar(cars));
		
		//but this is why we use generics instead of raw types...
		//raceStackRaw(makeStackString(strings));	//runtime error
		//raceStackRaw(makeStackInteger(ints));	//runtime error
		raceStackRaw(makeStackSportsCar(cars));	//actually works
		
		//So let's switch to Generics , Since Object defines println
		//we can use Stack<Object>, right ? no
		//printStackObject(makeStackString(strings));	//Compile error, Stack<Object> is not Compitable with Stack<String>
		//printStackObject(makeStackInteger(ints));	//Compile error
		//printStackObject(makeStackSportsCar(cars));	//Compile error
		
		//THe Compiler demands that we have exact matching types
		printStackString(makeStackString(strings));
		printStackInteger(makeStackInteger(ints));
		printStackSportsCar(makeStackSportsCar(cars));
		
		//It won't let us use Car because we have SportsCar
		//printStackCar(makeStackSportsCar(cars));
		
		//This is becoming too much work to use Generics, Right?
		//But we can use WildCard, Stack<?>, to fix it.
		printStack(makeStackString(strings));
		printStack(makeStackInteger(ints));
		printStack(makeStackSportsCar(cars));
		
		//The ? WildCard is acting as if it allows anything, but we treat 
		//the type as Object, since we know nothing else about it.
		
		
		//But what if we want to work with car types generically, e.g:,
		//set the speed, which is not a method of Object?
		Stack<Car> cars1= new StackArray<>();
		
		//Stack<Car> is OK as an exact match
		setSpeedStackCar(makeStackCar(cars1));
		//but we cannot use Stack<Car>, when we have Stack<SportsCar>
		//Stack<SportsCar> is not a Stack<Car>, even SportsCar is a Car
		
		//setSpeedStackCar(makeStackSportsCar(cars));
		
		//So now we learn that wildcards can be "bounded", so that ? isn't 
		//jsut Object, but perhaps something els, like Car. We can declare 
		//that the type is <? extends Car> -- something that EXTENDS Car
		//And now both are OK.
		setSpeedStackExtendsCar(makeStackCar(cars1));
		setSpeedStackExtendsCar(makeStackSportsCar(cars));
		
		//So now let's have a method that will populate a stack of Car types 
		//Right now, we have a Stack<Car> "and" a Stack<SportsCar>, let's
		//consolidate, and put them both in the stack<Car> 
		makeStackCar(cars1);
		//makeStackSportscar(cars1); //incompatible types!
		
		//OK,so lets do the <? extends Car> that we just learned
		//But it may look ok here, but the method, itself, shows errors!
		makeStackExtendsCar(cars1);
		
		//Methods using <? extends> can only read not assign
		//we need a new way, <? super Car> to be able to assign
		makeStackSuperCar(cars1);	//this works, <? super Car> can assign
		makeStackSuperCar(new StackArray<Object>()); //Stack<Object> is OK, because Object is parent of Car
		//makeStackSuperCar(cars);	//but you cant pass something using a subclass
		
		Stack<Car> c = loadFromArray(new Object[] { new SUV(), new SportsCar(), new StationWagon() }, Car.class);
		//Stack<Object> o = loadFromArray(new Object[] { new SUV(), new SportsCar(), new StationWagon() }, Car.class);
		
		if (ints.getClass() == strings.getClass()) {
			System.out.printf("Stack<Integer> and Stack<String>  are both %s !\n", ints.getClass());
		}


	}

}
