/**
 * 
 */
package com.lq.packages.DemoApps;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;

import com.lq.packages.transport.Car;
import com.lq.packages.transport.SUV;
import com.lq.packages.transport.SpeedException;
import com.lq.packages.transport.SportsCar;
import com.lq.packages.transport.StationWagon;
import com.lq.packages.transport.Train;
import com.lq.packages.transport.Vehicle;

/**
 * @author developer
 *
 */
public class VehicleApp {
	
	public static List<Vehicle> populate(){
		
		List<Vehicle> vehicles= new ArrayList<>();
		
		try {
			Car car1= new SportsCar();
			car1.setName("tata");
			car1.setSpeed(80);
			car1.setGasoline(50);
			car1.setRunning(true);
			car1.setManufactured(LocalDate.of(2001,3,26));
		} catch (SpeedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			Car car2= new SportsCar();
			car2.setName("kia");
			car2.setSpeed(60);
			car2.setRunning(false);
			car2.setGasoline(70);
			car2.setManufactured(LocalDate.of(1996, 4, 13));
		} catch (SpeedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		StationWagon wagon;
		try {
			wagon = new StationWagon("Station wagon", 50,60,true,LocalDate.of(1947, 8, 02));
			wagon.setCurrentCargoLoad(500);
		} catch (SpeedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SUV suv1;
		try {
			suv1 = new SUV("SUV", 50,60,true,LocalDate.of(1949, 8, 02));
		} catch (SpeedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Train train = new Train("Venkatadri Express");
		vehicles.add(train);
		
		/*
		 * Type reference = new Class(..);
		 *  SportsCar sc =new SportsCar(); 
		 *  Car car1 =(Car) sc; 
		 *  sc.race; 
		 *  c.race;
		 * 
		 */
		
		return vehicles;	
		
	}
	
	public static void main(String[] args) {
		
		
//		for(Vehicle vehicle: new Vehicle[] {car1, car2, wagon, suv1, train}) {
//			if(vehicle instanceof SportsCar) {
//				((SportsCar) vehicle).race();	//shortcut rather than SportsCar sc =(Sportscar) Car();
//			}
//			else {
//				Vehicle.travelAtSpeedLimit(vehicle);
//			}
//			System.out.println(vehicle);
//		}
		
		//List
		
		//List<Vehicle> vehicles = Arrays.asList(car1, car2, wagon, suv1, train);
		
		
//		//foreach with lambda function
//		vehicles.forEach( vehicle ->  {
//			if(vehicle instanceof SportsCar) 
//				((SportsCar) vehicle).race();
//			else
//				Vehicle.travelAtSpeedLimit(vehicle);
//			System.out.println(vehicle);
//		});
		 
		
		
//		vehicles.forEach( vehicle -> Vehicle.travelAtSpeedLimit(vehicle));
//		vehicles.forEach( vehicle -> System.out.println(vehicle));
		
		//show method reference as shorthand
		//vehicles.forEach(Vehicle::travelAtSpeedLimit);
		//vehicles.forEach(System.out::println);
		
		//more method references, compiler figures out what to do
		//vehicles.forEach(Vehicle::stop);	//vehicle -> vehicle.stop();
		//vehicles.forEach(System.out::println);
		
		//Otherwise , just go with the fleshed out lambdas
		//vehicles.forEach(vehicle -> vehicle.setSpeed(25));
		//vehicles.forEach(vehicle -> System.out.printf("%s is travelling at %d mph%n" ,vehicle.getName(), vehicle.getSpeed()));
	
//		Consumer<Integer> go25 = vehicle -> vehicle.setSpeed(25);
//		vehicles.forEach(go25.andThen(System.out::println));
		
		Collection<Integer> speeds = Arrays.asList(15,25,35,55,70);
		Consumer<Vehicle> stop = Vehicle::stop;
		
		speeds.forEach(speed -> {
			//Consumer<Vehicle> setSpeed = vehicle -> vehicle.setSpeed(speed);
			//vehicles.forEach(setSpeed.andThen(System.out::println));
			//Consumer<Vehicle> speedAndPrint = setSpeed.andThen(System.out::println);
			//vehicles.forEach(speedAndPrint.andThen(stop).andThen(System.out::println));
			
			
		});
	}
}
