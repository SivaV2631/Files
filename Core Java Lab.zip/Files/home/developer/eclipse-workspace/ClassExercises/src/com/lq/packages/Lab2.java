/**
 * 
 */
package com.lq.packages;

/**
 * @author developer
 *
 */
public class Lab2 {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		int width,height,area;
		 double radius=10.0, pi=3.14;
		boolean result=true;
		
		width=8;
		height=12;
		area=96;
		
		int[] daysInMonths = new int[12];
		String[] monthNames = {"January","February","March","April","May","June","July","Augest","September","October","November","December"};
		int[] days= {31,28,31,30,31,20,31,31,30,31,30,31};
		for(int i=0;i<daysInMonths.length;i++) {
			for(int j=0;j<days.length;j++) {
				daysInMonths[i] = days[i];
			}
		}
		
		for(int i=0;i<monthNames.length;i++) {
			System.out.println(monthNames[i] + " has " + daysInMonths[i] + " days.");
		}
		
		System.out.println("The value of width is " + width);
		System.out.println("The value of height is " + height);
		System.out.println("The value of area is " + area);
		System.out.println("The value of radius is " + radius);
		System.out.println("The value of pi is " + pi);
		System.out.println("The value of result is " + result);

	}

}
