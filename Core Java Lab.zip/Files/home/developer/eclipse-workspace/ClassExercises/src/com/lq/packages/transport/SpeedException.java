package com.lq.packages.transport;

public class SpeedException extends Exception {

	
	public SpeedException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
