package com.lq.packages;

public class ExerciseShapes {

	public static void main(String[] args) {
		
		Shape[] shapes = new Shape[8];
		
		shapes[0] = new Rectangle(10, 20);
		shapes[1] = new Rectangle(20, 30);
		
		shapes[2] = new Square(5);
		shapes[3] = new Square(10);
		
		shapes[4] = new Cube(5);
		shapes[5] = new Cube(10);
		
		shapes[6] = new Box(1,2,3);
		shapes[7] = new Box(10,20,30);
		
		for(Shape shape: shapes){
			shape.setColor("green");	
		}
		
//	for(Shape shape: shapes){
//		ThreeDimensional temp = (ThreeDimensional) shape;
//		if(temp instanceof ThreeDimensional )
//			System.out.println(temp.getVolume());
//	}
		
		TwoDimensional[]  twoDs = new TwoDimensional[3];
		
		twoDs[0] = new Circle(4.00);
		twoDs[1] = new Rectangle(10,20);
		twoDs[2] = new Square(5);
		
		for(TwoDimensional two : twoDs) {
			System.out.println(two.getArea());
			System.out.println(two.getPerimeter());
		}
		
		
		
	}

}
