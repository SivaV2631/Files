/**
 * 
 */
package com.lq.packages.transport;

import java.time.LocalDate;

/**
 * @author developer
 *
 */
public class SUV extends Cargo {

	/**
	 * 
	 */
	public SUV() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param carName
	 * @throws SpeedException 
	 */
	public SUV(String carName) throws SpeedException {
		super(carName);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param carName
	 * @param speed
	 * @param gasoline
	 * @param running
	 * @param manufactured
	 * @throws SpeedException 
	 */
	public SUV(String carName, int speed, int gasoline, boolean running, LocalDate manufactured) throws SpeedException {
		super(carName, speed, gasoline, running, manufactured);
		// TODO Auto-generated constructor stub
	}

}
