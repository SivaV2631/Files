package com.lq.packages;

public class Cube extends Box {

	public Cube() { }
	
	public Cube(double side) {
		super(side);
	}
	
	public Cube(double side, String name, String color) {
		super(side);
		this.setName(name);
		this.setColor(color);
	}
	


	@Override
	public void setHeight(double height) {
		if(height != super.getHeight()) {
			setSides(height);
			
		}
		
	}

	@Override
	public void setWidth(double width) {
		if(width != super.getWidth()) {
			setSides(width);
			
		}

	}

	@Override
	public void setLength(double length) {
		if(length != super.getLength()) {
			setSides(length);
		}	
	}
	
	public void setSides(double sides) {
		if(sides>0) {
			super.setHeight(sides);
			super.setLength(sides);
			super.setWidth(sides);
		}
		else {
			System.err.println("Passed value must be greater than zero -- Cube unchanged");
		}
	}
	
	public double getSides() {
		return super.getHeight();
	}
	

	
}
