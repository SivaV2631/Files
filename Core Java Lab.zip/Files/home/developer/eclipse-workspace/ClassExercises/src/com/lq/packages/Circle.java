package com.lq.packages;

public class Circle extends Shape implements TwoDimensional {
	
	public Circle(double radius) {
		this(radius, "White", "Unknown");
		
	}
	
	public Circle(double radius, String color, String name) {
		setRadius(radius);
		setColor("White");
		setName("Unknown");
		
	}
	
	private double radius;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	@Override
	public double getArea() {
		return (Math.PI * radius * radius);
	}

	@Override
	public double getPerimeter() {
		return (2 * Math.PI * radius);
	}
	
	@Override 
	public String toString() {
		
		StringBuilder builder = new StringBuilder();
		
		 builder.append("Circle [ Radius = ");
		 builder.append(radius);
		 builder.append(", Color = ");
		 builder.append(getColor());
		 builder.append(", Name = ");
		 builder.append(getName());
		 builder.append(", Area = ");
		 builder.append(getArea());
		 builder.append(", Perimeter = ");
		 builder.append(getPerimeter() + " ]");
		 
		 return builder.toString();
	}
	
	
	
}
