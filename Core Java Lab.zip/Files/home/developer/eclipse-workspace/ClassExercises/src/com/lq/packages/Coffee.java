package com.lq.packages;

public class Coffee {
	private int temparature;

	public Coffee(int temparature) throws TooHotException {
		super();
		this.setTemparature(temparature);
	}
	
	//default
	public Coffee() {	
		
	}

	
	public int getTemparature() {
		return temparature;
	}

	public void setTemparature(int temparature) throws TooHotException {
		if(temparature>120) {
			throw new TooHotException("Coffee is too hot");
		}
		else {	
			this.temparature = temparature;
		}
	}
	
}
