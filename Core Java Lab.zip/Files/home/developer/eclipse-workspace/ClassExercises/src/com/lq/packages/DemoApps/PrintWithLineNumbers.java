package com.lq.packages.DemoApps;

import static java.lang.System.out;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

public class PrintWithLineNumbers {
	
	public static void main(String[] args) {
		
		out.printf("Current Working Directory: %s\n",System.getProperty("user.dir"));
		
		try(FileInputStream inFile = new FileInputStream("/home/developer/eclipse-workspace/Demos/src/com/learnquest/demos/HelloWorld.java");
			InputStreamReader inStreamReader = new InputStreamReader(inFile); 
			LineNumberReader lineReader = new LineNumberReader(inStreamReader))
		{
			
//			//Pre- java 8 
//			String outputLine=null;
//			while((outputLine = lineReader.readLine()) != null) {
//				System.out.printf("%d: %s\n", lineReader.getLineNumber(), outputLine);
//				
//			}
			
			lineReader.lines().forEach(line -> System.out.printf("%d: %s\n", lineReader.getLineNumber(), line));
		
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
	}
	
}
