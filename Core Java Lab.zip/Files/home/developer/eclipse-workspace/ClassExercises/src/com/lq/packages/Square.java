package com.lq.packages;

public class Square extends Rectangle{


	public Square(double side) {
		super(side, side);
	}

	public Square(double length, double width, String name, String color) {
		super(length, width, name, color);
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}

