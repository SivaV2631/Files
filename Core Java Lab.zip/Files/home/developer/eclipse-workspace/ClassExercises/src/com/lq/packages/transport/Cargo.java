package com.lq.packages.transport;

import java.time.LocalDate;

public abstract class Cargo extends Car {

	private int cargoCapacity;
	private int currentCargoLoad;

	public Cargo() {
		super();
	}
	
	public Cargo(String carName) throws SpeedException{
		super(carName);
	}

	public Cargo(String carName, int speed, int gasoline, boolean running, LocalDate manufactured) throws SpeedException {
		super(carName, speed, gasoline, running, manufactured);
	}
	
	
	@Override
	public int getMaxSpeed() {
		// TODO Auto-generated method stub
		return 100;
	}



	/**
	 * @param currentCargoLoad the currentCargoLoad to set
	 */
	public void setCurrentCargoLoad(int currentCargoLoad) {
		this.currentCargoLoad = currentCargoLoad;
	}

	@Override
	public void setSpeed(int speed) throws SpeedException {
		
		super.setSpeed(speed= getCurrentCargoLoad() / 100);
	}

	public int getCurrentCargoLoad() {
		return currentCargoLoad;
	}

	

}