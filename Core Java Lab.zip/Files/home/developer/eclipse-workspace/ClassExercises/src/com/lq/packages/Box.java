/**
 * 
 */
package com.lq.packages;

/**
 * @author developer
 *
 */
public class Box extends Shape implements ThreeDimensional {
	
	private double height=1;
	private double width=1;
	private double length=1;
	
	public Box() {		//default constructor
		
	}
	
	/**
	 * @param height
	 * @param width
	 * @param length
	 */
	public Box(double height, double width, double length) {
		
		if(height>0) 
			this.height = height;
		if(width>0)
			this.width = width;
		if(length>0)
			this.length = length;
	}

	public Box(double side) {
			this(side,side,side);				
	}
	
	public Box(double side,String name, String color) {
		this(side,side,side);	
		this.setName(name);
		this.setColor(color);
}
	

	/**
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}


	/**
	 * @param height the height to set
	 */
	public void setHeight(double height) {
		if(height>0)
			this.height = height;
		else
			System.out.println("Height must be greater than 0");
	}


	/**
	 * @return the width
	 */
	public double getWidth() {
		return width;
	}


	/**
	 * @param width the width to set
	 */
	public void setWidth(double width) {
		if(width>0)
			this.width = width;
		else
			System.out.println("Width must be greater than 0");

	}


	/**
	 * @return the length
	 */
	public double getLength() {
		return length;
	}


	/**
	 * @param length the length to set
	 */
	public void setLength(double length) {
		if(length>0)
			this.length = length;
		else
			System.out.println("Length must be greater than 0");

	}
	
	/**
	 * 
	 * @return the volume of the box
	 */
	@Override
	public double getVolume() {
		return (length*width*height);
	}
	
	/**
	 * 
	 * @return the surface area of the box
	 */
	@Override
	public double getSurfaceArea() {
		return (( width*length + length*height + height*width )*2);
	}
	
	public void printBox() {
		if(length<=0 || width<=0 || length<=0) {
			System.out.println("Box contains invalid properties");
		}
		else  {
			System.out.println("Length = " + length);
			System.out.println("Width = " + width);
			System.out.println("Height = " + height);
			System.out.println("Volume = " + getVolume());
			System.out.println("Surface Area = " + getSurfaceArea());
			
		}
	}
	
	/*
	 * (Non-Javadoc)
	 * see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		builder.append("Box [ Length = ");
		builder.append(length);
		builder.append(", Width = ");
		builder.append(width);
		builder.append(", Height = ");
		builder.append(height);
		builder.append(", Color = ");
		builder.append(getColor());
		builder.append(", Name = ");
		builder.append(getName() + " ]");
		
		return builder.toString();
		
	}
	
	
	


}
