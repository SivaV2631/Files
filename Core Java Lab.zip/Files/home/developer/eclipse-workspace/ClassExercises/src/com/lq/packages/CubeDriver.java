package com.lq.packages;

public class CubeDriver {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cube cube1= new Cube(5);
		Cube cube2 = new Cube(8);
		
		System.out.println("Cube 1 length is = " + cube1.getLength());
		System.out.println("Cube 1 Height is = " + cube1.getHeight());
		System.out.println("Cube 1 Width is = " + cube1.getWidth());
		
		System.out.println();
		
		System.out.println("Cube 2 length is = " + cube2.getLength());
		System.out.println("Cube 2 Height is = " + cube2.getHeight());
		System.out.println("Cube 2 Width is = " + cube2.getWidth());		
		
		
		cube1.setLength(20);
		cube1.printBox();
		System.out.println();
		
		cube1.setLength(40);
		cube1.printBox();
		System.out.println();
		
		cube2.setWidth(-5);
		cube2.printBox();
		
		cube1.setHeight(-10);
		cube1.printBox();
		
		
		
		
	}

}
