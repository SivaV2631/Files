package com.lq.packages;

public class TooHotException extends Exception {

	public TooHotException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TooHotException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
