/**
 * 
 */
package com.lq.packages.transport;

/**
 * @author developer
 *
 */

import java.time.LocalDate;

import java.lang.Math;
import java.time.Period;



public abstract class Car implements Vehicle {

	/**
	 * @param args
	 */
	
	private String name;
	private int speed;
	private int gasoline;
	private boolean running;
	private LocalDate manufactured;
	
	
	public Car() { }
	
	
	/**
	 * @param name
	 */
	public Car(String carName) {
		super();
		this.name=carName;
	}


	/**
	 * @param name
	 * @param speed
	 * @param gasoline
	 * @param running
	 * @param manufactured
	 * @throws SpeedException 
	 */
	public Car(String name, int speed, int gasoline, boolean running, LocalDate manufactured) throws SpeedException {
		super();
		setName(name);
		setSpeed(speed);
		setGasoline(gasoline);
		setRunning(running);
		setManufactured(manufactured);
	}


	public Car(String name, int speed, int gasoline, boolean running) {
		super();
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	//private static final int MAX_SPEED=350;
	
	/*
	 * abstract method
	 */
	public abstract int getMaxSpeed();

	public int getSpeed() {
		return speed;
	}
	
	public void setSpeed(int speed) throws SpeedException {
		//speed = min(speed, MAX_SPEED);
		//his.speed = Math.min(speed, getMaxSpeed());
		if(speed > getMaxSpeed()) {
			throw new SpeedException(String.format("%s cannot go %dmph, Max speed is %d mph", getName(), name, getMaxSpeed()));
		}
		this.speed =speed;
	}


	public int getGasoline() {
		return gasoline;
	}


	public void setGasoline(int gasoline) {
		this.gasoline = gasoline;
	}


	public boolean isRunning() {
		return running;
	}


	public void setRunning(boolean running) {
		this.running = running;
	}
	
	public LocalDate getManufactured(){
		return manufactured;
	}
	
	public void setManufactured(LocalDate manufactured) {
		this.manufactured = manufactured;
	}
	
	public int getAge() {
		return Period.between(getManufactured(),LocalDate.now()).getYears();
	}


	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Car))
			return false;
			
		Car other = (Car) obj;
		
		return name.equals(other.getName());
	}


	@Override
	public int hashCode() {
		
		return name.hashCode();
	}


	@Override
	public String toString() {
		if(manufactured == null)
			return String.format("%s has %d gas , %d speed running ", getName(),getGasoline(),getSpeed());
		else
			return String.format("%s has %d gas , %d speed running and it is %d years old", getName(),getGasoline(),getSpeed(),getAge());

	}
	
	


	

}
