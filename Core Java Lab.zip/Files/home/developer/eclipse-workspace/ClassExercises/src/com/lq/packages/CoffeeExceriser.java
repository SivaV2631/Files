package com.lq.packages;

public class CoffeeExceriser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Coffee coffee = new Coffee();
		
		try {
			coffee.setTemparature(110);
			coffee.setTemparature(130);
		} catch (TooHotException e){
			System.out.println(e.getMessage());
		}finally {
			System.out.println("Coffee is set to " + coffee.getTemparature());
		}

	}

}
