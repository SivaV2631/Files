package com.lq.packages;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.LinkedBlockingDeque;

public class GenericStackImpl<E> implements Stack<E> {
	
	Deque<E> stack;
	java.util.Stack<E> legacyStack;
	
	public GenericStackImpl() {
		switch(new java.util.Random().nextInt(5)) {
		case 0:
			stack = new LinkedList<E>();
			break;
		case 1:
			stack = new ArrayDeque<E>();
			break;
		case 2: 
			stack = new ConcurrentLinkedDeque();
			break;
		case 3:
			stack = new LinkedBlockingDeque();
			break;
		default:
			legacyStack = new java.util.Stack<E>();
			break;
		}
		
		System.out.printf("Using %s as the Stack<E> implementation \n ", (stack != null ? stack : legacyStack).getClass().getName());
	}
	
	@Override
	public void push(E element) {
		if(stack != null) 
			stack.push(element) ;
		else
			legacyStack.push(element) ;
		
	}

	@Override
	public E pop() {
		if(stack != null) 
			return stack.pop() ;
		else
			return legacyStack.pop() ;
	}

}
