package com.devtech.training.transportation;

import com.lq.packages.transport.Vehicle;

public class Train implements Vehicle {

	public Train(String name) {
		setName(name);
		setWheelSize(60);
	}

	private String name;
	private int rpms;
	private int wheel_size;

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int getSpeed() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setSpeed(int Speed) {
		// TODO Auto-generated method stub

	}

	public int getRPM() {
		return rpms;
	}

	public void setRPM(int rpms) {
		this.rpms = rpms;
	}

	public int getWheelSize() {
		return wheel_size;
	}

	public void setWheelSize(int wheel_size) {
		this.wheel_size = wheel_size;
	}

}
