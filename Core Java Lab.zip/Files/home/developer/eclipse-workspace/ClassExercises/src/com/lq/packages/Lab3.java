package com.lq.packages;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] daysOfWeek = {"sunday","monday","tuesday","wednesday","thursday","friday","saturday"};
		for(int i=0; i<daysOfWeek.length; i++) {
			System.out.println(daysOfWeek[i]);
		}
		for(String s: daysOfWeek) {
			System.out.println(s);
		}
		for(int j=daysOfWeek.length-1; j>=0; j--) {
			System.out.println(daysOfWeek[j]);
		}
		
		int i=0;
		while(i<=20) {
			if(i%2==0) {
				System.out.println(i);
				i++;
				
			}
			i++;	
		}
		
		int j=0;
		while(j<=20) {
			j++;
			if(j%2==1) {
				continue;
			}
			
			System.out.println(j);
		}
		
		for(int k=1;k<=100;k++) {
			
			if(k>=50 && k<=60) {
				continue;
			}
			System.out.println(k);
			
		}
		
		
		
		String[] monthNames = {"January","February","March","April","May","June","July","Augest","September","October","November","December"};
		
		
		
		
		int monthCount=1;
		while(monthCount<=12) {
			switch(monthCount) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				System.out.println("There are 31 days in " + monthNames[monthCount-1]);
				break;
			case 4:
			case 6:
			case 9:
			case 11:
		System.out.println("There are 30 days in " + monthNames[monthCount-1]);
				break;
			case 2:
				System.out.println("There are 28 days in " + monthNames[monthCount-1]);
				break;
			default:
				System.out.println("Error, Invalid Month number!");
			}
			monthCount++;
		}
		
		int dayCount=1;
		int leftOff=4;
		boolean printing=false;
		System.out.println("sun mon tue wed thu fri sat");
		for(int y=0;y<5;y++) {
			for(int x=0;x<7;x++) {
				if(printing==false) {
					System.out.print("    ");
					if(x==leftOff) {
						printing=true;
					}
				}
				else if(dayCount<10){
					System.out.print(dayCount +"   ");
					dayCount++;
					
				}
				else {
					System.out.print(dayCount +"  ");
					dayCount++;
				}
			}
			System.out.println();
			
		}


	}

}
