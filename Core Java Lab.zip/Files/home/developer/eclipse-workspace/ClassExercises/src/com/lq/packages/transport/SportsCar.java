/**
 * 
 */
package com.lq.packages.transport;

import java.time.LocalDate;

/**
 * @author developer
 *
 */
public class SportsCar extends Car {

	public SportsCar() {
		
	}

	/**
	 * @param carName
	 */
	public SportsCar(String Name) throws SpeedException{
		super(Name);
		
	}

	/**
	 * @param name
	 * @param speed
	 * @param gasoline
	 * @param running
	 * @param manufactured
	 * @throws SpeedException 
	 */
	public SportsCar(String name, int speed, int gasoline, boolean running, LocalDate manufactured) throws SpeedException {
		super(name, speed, gasoline, running, manufactured);
		// TODO Auto-generated constructor stub
	}

	public SportsCar(String name, int speed, int gasoline, boolean running) {
		// TODO Auto-generated constructor stub
		super(name, speed, gasoline, running);
		
	}

	

	@Override
	public void setSpeed(int speed) throws SpeedException {
		super.setSpeed((int) (speed * 1.10));
		
	}

	@Override
	public int getMaxSpeed() {
		// TODO Auto-generated method stub
		return 350;
	}
	
	public void race() {
		try {
			//setSpeed((int) getMaxSpeed() / 1.10);
			setSpeed(getMaxSpeed());
		} catch (SpeedException e) {
			System.out.println("Unexpected error: we tried to race, but were told that max speed was too fast. see the stack trace for details %s");
			e.printStackTrace();
		}
	}

}
