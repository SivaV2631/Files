package com.lq.packages.DemoApps;

import java.io.File;

public class DirectoryChecker {

	public static void main(String[] args) {
		
		File aDirectory = new File(".");
		if(aDirectory.isDirectory()) {
			String[] contents = aDirectory.list();
			for(int i=0; i<contents.length; i++) {
				System.out.println(contents[i]);
				
			}
		}

	}

}
