package com.lq.packages;

public interface ThreeDimensional {
	
	public double getVolume();
	
	public double getSurfaceArea();
	
}
