package com.lq.generics;

import static com.lq.generics.GenericMethod.printArray;

public class GenericMethodExerciser {

	public static void main(String[] args) {
		Integer[] integerArray = {1,2,3,4,5};
		Double[] doubleArray = {1.1,2.2,3.3,4.4};
		Character[] charArray = {'H', 'E', 'L', 'L', 'O'};
		
		System.out.println("Integer array contains");
		printArray(integerArray);
		System.out.println("Double array contains");
		printArray(doubleArray);
		System.out.println("Char array contains");
		printArray(charArray);
	}

}
