package com.lq.generics;
import static com.lq.generics.Maximum.maximum;
public class MaximumExerciser {

	public static void main(String[] args) {
		System.out.printf("Maximum of %d,%d and %d is %d\n", 3,4,5,maximum(3,4,5));
		System.out.printf("Maximum of %.1f,%.1f and %.1f is %.1f\n", 1.1,2.2,3.3,maximum(1.1,2.2,3.3));
		System.out.printf("Maximum of %s,%s and %s is %s\n", "pear","apple","orange",maximum("pear","apple","orange"));

	}

}