package com.lq.generics;

import static java.lang.System.out;
public class GenericBoxExerciser {

	public static void main(String... args) {
		
		GenericBox<String> s = new GenericBox<>();
		GenericBox<Integer> i = new GenericBox<>();
		
		s.setT("Hello world");
		i.setT(10);
		
		out.printf("String value is %s\n" ,  s.getT());
		out.printf("Integer value is %d" , i.getT());
		
	
		
		
		
		
	}
}