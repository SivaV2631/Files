/**
 * 
 */
package com.javoo.calculators;

/**
 * @author developer
 *
 */
public class ScientificCalculator {

	/**
	 * @param args
	 */
	public static final double PI = 3.14159;
	private double holdValue;
	
	public static final double exp(double x) {
		System.out.printf("Exp  of %f = %f "  ,x, Math.exp(x));
		System.out.println();
		return Math.exp(x);
	}
	
	public static final double log(double x) {
		System.out.printf("Log of %f =  %f"  ,x, Math.log(x));
		System.out.println();
		return Math.log(x);
	}
	
	public void putValueInMemory(double holdValue) {
		this.holdValue=holdValue;
	}
	
	public double getValueFromMemory() {
		System.out.println("getValueFromMemory = "  + holdValue);
		return(holdValue);
	}
	

}
