/**
 * 
 */
package com.javoo.calculators;

/**
 * @author developer
 *
 */
public class TrigonometricCalculator {

	/**
	 * @param args
	 */
	
	public double sine(double x) {
		System.out.printf("sine of %f =  %f" ,x,Math.sin(x));
		System.out.println();
		return Math.sin(x);
		
	}
	
	public double cosine(double x) {
		System.out.printf("cosine of %f =  %f" ,x,Math.cos(x));
		System.out.println();
		return Math.cos(x);
	}
	
	public double tangent(double x) {
		System.out.printf("tangent of %f =  %f" ,x,Math.tan(x));
		System.out.println();
		return Math.tan(x);
	}
	
	public double arcsine(double x) {
		System.out.printf("arcsine of %f =  %f" ,x,Math.asin(x));
		System.out.println();
		return Math.asin(x);
	}
	
	public double arccosine(double x) {
		System.out.printf("arccosine of %f =  %f" ,x,Math.acos(x));
		System.out.println();
		return Math.acos(x);
	}
	
	public double arctangent(double x) {
		System.out.printf("arctangent of %f =  %f" ,x,Math.atan(x));
		System.out.println();
		return Math.atan(x);
	}
	

}
