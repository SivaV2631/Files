/**
 * 
 */
package com.javoo.calculators;

/**
 * @author developer
 *
 */
public class CaluculatorDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		BasicCalculator basic=new BasicCalculator();
		ScientificCalculator scientific = new ScientificCalculator();
		TrigonometricCalculator trigono = new TrigonometricCalculator();
		
		System.out.println("BasicCalculator Example:");
		
		basic.add(2, 2);		
		basic.subtract(5, 3);
		basic.multiply(5, 2);
		basic.divide(10, 2);
		System.out.println();
		
		System.out.println("ScientificCalculator Example:");
		scientific.exp(10);
		scientific.log(2);
		scientific.putValueInMemory(5);
		scientific.getValueFromMemory();
		System.out.println();
		
		System.out.println("TrigonometricCalculator Example:");
		trigono.sine(30);
		trigono.cosine(30);
		trigono.tangent(30);
		trigono.arcsine(30);
		trigono.arccosine(30);
		trigono.arctangent(30);
			

	}

}
