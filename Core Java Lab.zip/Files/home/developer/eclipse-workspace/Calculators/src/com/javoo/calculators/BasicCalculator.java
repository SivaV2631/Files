/**
 * 
 */
package com.javoo.calculators;

/**
 * @author developer
 *
 */
public class BasicCalculator {

	/**
	 * @param args
	 */
	public final double add(double x, double y) {
		System.out.printf("Add of %f, %f = %f" ,x,y, (x+y));
		System.out.println();
		return x+y;
		
	}
	
	public final double subtract(double x, double y) {
		System.out.printf("Sub of %f, %f = %f" ,x,y, (x-y));
		System.out.println();
		return x-y;
	}
	
	public final double multiply(double x, double y) {
		System.out.printf("Multiply of %f, %f = %f" ,x,y, (x*y));
		System.out.println();
		return x*y;
	}
	
	public final double divide(double x, double y) {
		System.out.printf("Divison of %f, %f = %f" ,x,y, (x/y));
		System.out.println();
		return x/y;
	}


}
