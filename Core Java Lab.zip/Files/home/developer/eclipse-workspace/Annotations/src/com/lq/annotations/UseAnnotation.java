package com.lq.annotations;


@MyAnnotation(id=123, name="siva")
public class UseAnnotation {

}
