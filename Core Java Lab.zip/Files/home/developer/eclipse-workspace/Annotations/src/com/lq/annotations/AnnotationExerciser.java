package com.lq.annotations;

import java.lang.annotation.Annotation;

public class AnnotationExerciser {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Class[] classes = {UseAnnotation.class};
		
		for(Class classObj : classes) {
			Annotation[] annotations = classObj.getAnnotations();
			System.out.println("Number of Annotations : " + annotations.length);
			for(Annotation annotation : annotations) {
				MyAnnotation a = (MyAnnotation) annotation;
				System.out.println(a.name());
			}
			
		}
		

	}

}
