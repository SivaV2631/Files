package com.javoo.store.drivers;

import java.util.Date;

import com.javoo.store.Artist;
import com.javoo.store.Book;
import com.javoo.store.CD;
import com.javoo.store.ClassicalCD;
import com.javoo.store.Inventory;
import com.javoo.store.Item;

public class InventoryDriver {

	public static void main(String[] args) {
		
		Item[] myInventory =new Item[50];
		
		
		myInventory[0]= new Book("Book1", 100.00, 10, "Author1", "Publisher1", "Category1");
		myInventory[1]= new Book("Book2", 200.00, 20, "Author2", "Publisher2", "Category2");
		myInventory[2]= new Book("Book3", 300.00, 30, "Author3", "Publisher3", "Category3");
		myInventory[3]= new Book("Book4", 400.00, 40, "Author4", "Publisher4", "Category4");
		myInventory[4]= new Book("Book5", 500.00, 50, "Author5", "Publisher5", "Category5");
		
		myInventory[5]= new CD("CD1", 100.00, 10, new Artist("Artist1"), new Date("26/08/2023"));
		myInventory[6]=  new CD("CD2", 200.00, 20, new Artist("Artist2"), new Date("27/08/2023"));	
		myInventory[7]= new  CD("CD3", 300.00, 30, new Artist("Artist3"), new Date("28/08/2023"));	
		
		String[] performers1 = {"siva","jashwanth","kalyan","joseph"};
		myInventory[8] = new ClassicalCD("ClassicalCD1",100.00,10,"composer1",performers1,"Bangalore",new Date("30/08/2023"));
		
		String[] performers2 = {"siva","jashwanth","kalyan","joseph"};
		myInventory[9] = new ClassicalCD("ClassicalCD2",100.00,10,"composer2",performers2,"Chittoor",new Date("31/08/2023"));
		
		Inventory.produceReport(myInventory);

	}

}
