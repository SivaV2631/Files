package com.javoo.store.drivers;

import java.util.SortedSet;
import java.util.TreeSet;
import static java.lang.System.out;

import com.javoo.store.Artist;

public class ArtistExerciser {
		
	public static void main(String[] args) {
		
		Artist hotPlate = new Artist();
		
		TreeSet<String> instruments1 = new TreeSet<>();
		instruments1.add("Piano");
		instruments1.add("guitar");
		instruments1.add("Flute");
		hotPlate.addMember("tom", instruments1);
		
		TreeSet<String> instruments2 = new TreeSet<>();
		instruments2.add("violin");
		instruments2.add("Drums");
		instruments2.add("Acoustic");
		hotPlate.addMember("siva", instruments2);
		
		 printMemberInstruments(hotPlate,"tom" ); 
		printMemberInstruments(hotPlate,"siva" );
		
	}
	
	private static void printMemberInstruments(Artist artist, String memberName) {
		out.println("HotPlate Band Member " + memberName + " plays: ");
		
		  for(String instrument : artist.getInstruments(memberName)) { 
			  out.println('\t'+ instrument); 
		
		  }
	
	
	}
}
