package com.javoo.store;

public class Inventory {

	public static void produceReport(Item[] items) {
		int totalCount=0;
		double totalValue=0.00;
		
		System.out.printf("%.30s%10s%5s\n ", "Title", " Price ","Quantity");
		
		for(Item item : items) {
			if(item != null) {
				System.out.printf("%.30s%10.2f%5d\n", item.getTitle(), item.getPrice(), item.getQuanity());
				totalCount += item.getQuanity();
				totalValue += (item.getQuanity() * item.getPrice());		
			}
		}
		System.out.printf("%.30s%10.2f%5d\n", "", totalValue, totalCount);
	}

}
