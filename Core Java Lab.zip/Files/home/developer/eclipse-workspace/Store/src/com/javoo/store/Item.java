package com.javoo.store;

public class Item {
	
	private String title;
	private double price;
	private int quanity;
	
	public Item() {}
	
	public Item(String title, double price, int quanity) {
		this.setTitle(title);
		this.setPrice(price);
		this.setQuanity(quanity);
	}

	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getQuanity() {
		return quanity;
	}
	
	public void setQuanity(int quanity) {
		this.quanity = quanity;
	}
	
	
	
}
